package com.Kampai.Kampai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KampaiApplication {

	public static void main(String[] args) {
		SpringApplication.run(KampaiApplication.class, args);
	}

}
